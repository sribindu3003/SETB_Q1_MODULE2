use [Training_19Sep19_Pune]
go
create schema [46009745]
go
create table [46009745].employeesMarathon
(
ID varchar(6) primary key not null,
Name varchar(15),
Gender varchar(6),
Location varchar(10),
Contact varchar(10),
BloodGroup varchar(6),
Coverage varchar(6))

use [Training_19Sep19_Pune]
go
create schema [46009745]
go
create procedure [46009745].[Register.._Details]
(@ID varchar(6), 
@Name varchar(15),
@Gender varchar(6),
@Location varchar(10),
@Contact varchar(10),
@BloodGroup varchar(6),
@Coverage varchar(6)
)
AS 
begin
Insert into [46009745].employeesMarathon values(@ID  , @Name , @Gender, @Location, @Contact, @BloodGroup, @Coverage )
end

