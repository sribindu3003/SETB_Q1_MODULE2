﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Employee_DAL;
using Employee_Entities;
using Employee_Exceptions;
using System.Text.RegularExpressions;

namespace Employee_BAL
{
  
        public class EmployeeBL
        {
            public static bool ValidateEmployee(Employee newEmp)
            {
                StringBuilder message = new StringBuilder();
                bool validEmployee = true;

                try
                {
                    if (newEmp.EmployeeId == string.Empty)
                    {
                        message.Append("Employee Id should be provided\n");
                        validEmployee = false;
                    }
                    else if (!Regex.IsMatch(newEmp.EmployeeId, "[0-9]{6}"))
                    {
                        message.Append("Employee Id should contain 6 digits exactly\n");
                        validEmployee = false;
                    }
                    if (newEmp.EmpName == string.Empty)
                    {
                        message.Append("Employee name should be provided\n");
                        validEmployee = false;
                    }
                    else if (!Regex.IsMatch(newEmp.EmpName, "^[A-Z][a-z]+"))
                    {
                        message.Append("Employee name should start with Capital letter and it should have alphabets only\n");
                        validEmployee = false;
                    }


                    if (newEmp.Gender == string.Empty)
                    {
                        message.Append("Gender should be provided\n");
                        validEmployee = false;
                    }




                    if (newEmp.ContactNo == String.Empty)
                    {
                        message.Append("Contact number should be provided\n");
                        validEmployee = false;
                    }
                    else if (!Regex.IsMatch(newEmp.ContactNo, "[7-9][0-9]{9}"))
                    {
                        message.Append("Contact number should start with 7 or 8 or 9 and it should have exactly 10 digits\n");
                        validEmployee = false;
                    }

                    if (validEmployee == false)
                    {
                        throw new EmployeeException(message.ToString());
                    }
                }
                catch (EmployeeException ex)
                {
                    throw ex;
                }
                catch (SystemException ex)
                {
                    throw ex;
                }

                return validEmployee;
            }
            public static int AddEmployeeBL(Employee employee)
            {
                int employeeAdded = 0;
                try
                {
                    if (ValidateEmployee(employee))
                    {
                        EmployeeDAL employeeDAL = new EmployeeDAL();
                        employeeAdded = EmployeeDAL.RegisterEmployee(employee);
                        return employeeAdded;
                    }
                }
                catch (EmployeeException ex)
                {
                    throw ex;
                }
                catch (Exception ex)
                {
                    throw ex;
                }
                return employeeAdded;
            }
        }
    
}
