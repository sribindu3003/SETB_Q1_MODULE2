﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using Employee_BAL;
using Employee_Entities;
using Employee_Exceptions;


namespace EmployeeMarathon
{
    /// <summary>
    /// Interaction logic for RegisterEmployee.xaml
    /// </summary>
    public partial class RegisterEmployee : Window
    {
        public RegisterEmployee()
        {
            InitializeComponent();
        }

        private void btnRegister_Click(object sender, RoutedEventArgs e)
        {
            Employee newEmp = new Employee();

            try
            {
                newEmp.EmployeeId = txtId.Text;
                newEmp.EmpName = txtName.Text;
                if (rd_Male.IsChecked == true)
                {
                    newEmp.Gender = "Male";
                }
                else
                {
                    newEmp.Gender = "Female";
                }
                newEmp.Location = txtLocation.Text;
                newEmp.ContactNo = txtContact.Text;
                newEmp.BloodGrp = txtBloodGrp.Text;
                newEmp.Coverage = txtCoverage.Text;

                int custInserted = EmployeeBL.AddEmployeeBL(newEmp);

                if (custInserted > 0)
                {
                    MessageBox.Show("Thank you! Details successfully registered");
                    Clear();
                    //Display();
                }
                else
                    throw new EmployeeException("Customer record not inserted");
            }
            catch (EmployeeException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }

        }

        private void btnReset_Click(object sender, RoutedEventArgs e)
        {
            Clear();
        }

        public void Clear()
        {
            txtId.Text = "";
            txtName.Text = "";


            txtLocation.Text = "";
            txtContact.Text = "";
            txtBloodGrp.Text = "";
            txtCoverage.Text = "";

            //btnDelete.Enabled = false;
            //btnUpdate.Enabled = false;

        }

        private void Rd_Male_Checked(object sender, RoutedEventArgs e)
        {
            //if( rd_Male.G == trur)
        }
    }
}
