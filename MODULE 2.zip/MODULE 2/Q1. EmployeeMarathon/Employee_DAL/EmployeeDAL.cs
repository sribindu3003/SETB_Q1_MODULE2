﻿using System;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;
using Employee_Entities;
using Employee_Exceptions;


namespace Employee_DAL
{
    public class EmployeeDAL
    {


        public static int RegisterEmployee(Employee objEmployee)
        {
            int employeeAdded = 0;
            SqlConnection objCon = null;
            try
            {
                objCon = new SqlConnection(
                    ConfigurationManager.ConnectionStrings["HRDSConnectionString"].ConnectionString);
                SqlCommand objCom = new SqlCommand("[46009745].[Register.._Details]", objCon);
                objCom.CommandType = CommandType.StoredProcedure;
                //
                SqlParameter objSqlParam_Id        =    new SqlParameter("@ID", objEmployee.EmployeeId);
                SqlParameter objSqlParam_Name      =    new SqlParameter("@Name", objEmployee.EmpName);
                SqlParameter objSqlParam_BloodGrp  =    new SqlParameter("BloodGroup", objEmployee.BloodGrp);
                SqlParameter objSqlParam_ContactNo =    new SqlParameter("@Contact", objEmployee.ContactNo);
                SqlParameter objSqlParam_Coverage  =    new SqlParameter("@Coverage", objEmployee.Coverage);
                SqlParameter objSqlParam_Location  =  new SqlParameter("@Location", objEmployee.Location);
                SqlParameter objSqlParam_Gender    =     new SqlParameter("@Gender", objEmployee.Gender);



                objCom.Parameters.Add(objSqlParam_Id);
                objCom.Parameters.Add(objSqlParam_Name);
                objCom.Parameters.Add(objSqlParam_BloodGrp);
                objCom.Parameters.Add(objSqlParam_ContactNo);
                objCom.Parameters.Add(objSqlParam_Coverage);
                objCom.Parameters.Add(objSqlParam_Location);
                objCom.Parameters.Add(objSqlParam_Gender);

                //
                objCon.Open();
                objCom.ExecuteNonQuery();
                employeeAdded = 1;
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return employeeAdded;
        }

    }
}
